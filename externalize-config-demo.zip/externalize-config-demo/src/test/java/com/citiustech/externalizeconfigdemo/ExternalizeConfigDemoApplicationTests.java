package com.citiustech.externalizeconfigdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExternalizeConfigDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
